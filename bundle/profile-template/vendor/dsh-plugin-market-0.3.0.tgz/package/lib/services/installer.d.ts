import { PluginCache } from '../db/cache.js';
import type { InstallResult, UninstallResult, UpdateResult, InstalledPlugin, InstallStatus, InstallOptions, IInstallerService } from '../types.js';
export declare class InstallerService implements IInstallerService {
    private cache;
    private dshClient;
    private defaultProfile;
    private confirmBeforeInstall;
    private loader?;
    private installingPlugins;
    private autoDetectPromise;
    constructor(cache: PluginCache, dshCommand?: string, defaultProfile?: string, confirmBeforeInstall?: boolean);
    bindLoader(loader: {
        entries?: () => Iterable<{
            options?: {
                name?: string;
            };
        }>;
    }): void;
    collectInstalledNames(): string[];
    refreshInstalledFlags(): Promise<void>;
    /**
     * 自动检测 dsh 命令（全局 dsh 或 npx）
     * 如果用户已显式指定 dshCommand，则跳过检测
     */
    ensureDshAvailable(): Promise<boolean>;
    /**
     * 安装插件
     */
    install(pluginId: string, options?: InstallOptions): Promise<InstallResult>;
    /**
     * 卸载插件
     */
    uninstall(pluginId: string, options?: {
        profile?: string;
    }): Promise<UninstallResult>;
    /**
     * 更新插件
     */
    update(pluginId: string, options?: {
        profile?: string;
    }): Promise<UpdateResult>;
    /**
     * 获取已安装插件列表
     */
    getInstalled(): Promise<InstalledPlugin[]>;
    /**
     * 检查插件是否已安装
     */
    isInstalled(pluginId: string): Promise<boolean>;
    /**
     * 获取安装状态
     */
    getStatus(pluginId: string): Promise<InstallStatus>;
    /**
     * 检查 dsh CLI 是否可用（会触发自动检测）
     */
    isDshAvailable(): Promise<boolean>;
    /**
     * 从插件对象中提取安装标识
     */
    private extractInstallSpec;
}
//# sourceMappingURL=installer.d.ts.map